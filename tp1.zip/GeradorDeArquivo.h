//
// Created by joaozenobio on 30/10/2021.
//

#ifndef TP_ARVOREB_TESTE_GERADORDEARQUIVO_H
#define TP_ARVOREB_TESTE_GERADORDEARQUIVO_H


#include "ManipulacaoDeArquivos.h"

int gerar_arquivo_aleatorio(int quantidade, int situacao);
int pesquisar(int* lista, int quantidade, int chave);


#endif //TP_ARVOREB_TESTE_GERADORDEARQUIVO_H
