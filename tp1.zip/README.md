# TRABALHO PRÁTICO ESTRUTURA DE DADOS 2

### Alunos 
- Joao Gabriel Fernandes Zenobio
- Luiz Fernando Rodrigues Fernandes 
- Sthéphany Karoline Soares De Araújo Tezza

---
### Temas:
1. Acesso sequencial indexado
2. Árvore binária de pesquisa adequada à memória externa.
3. Árvore B 
4. Árvore B*
---
O objetivo deste trabalho prático consiste em um estudo da complexidade de desempenho dos métodos de pesquisa externa apresentados acima.
O trabalho foi feito ultilizando a linguagem de programação C++, afim de testar as habilidades aprendidas em sala de aula.

